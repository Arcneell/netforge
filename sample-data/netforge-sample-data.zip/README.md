# NetForge — sample inventory

Drop this archive into `/import` → "Tout en un (auto)" — the backend detects each
entity from its headers and respects the dependency order.

Scenario: a French SME with two sites (PAR = HQ Paris, RBX = Datacenter Roubaix),
8 rooms, 12 switches (Cisco Catalyst / Nexus + one legacy Aruba 2930F), 17
VLANs, 17 subnets, ~30 devices and ~80 IPs.

Built-in problems for the AI features to surface:

- **suggest-links** : SW-EDGE-PAR-R301:24 carries the hint
  "uplink to SW-CORE-PAR-01 port gi1/0/48" in `notes` but no link is recorded —
  the model should propose it with high confidence.

- **advisor** :
  - SW-CORE-PAR-01 is the only path between every Paris edge and the WAN → SPOF
    on the Paris core.
  - SW-CORE-RBX-02 is patched + powered but has no recorded link → redundancy
    intent never realised, port 1 even has a "reserved redundancy" label.
  - Subnet 10.10.21.0/24 (USERS-IT) is filled to ~50/254 with DHCP leases — a
    real "you'll be tight in N weeks" capacity warning.
  - "switch-old-ipmi" management IP sits on the PAR MGMT subnet (10.10.10.99)
    while the switch lives in Roubaix DC1 → mis-segmentation + naming
    inconsistency vs every other switch's SW-* convention.
  - Aruba 2930F vs Cisco 9500/9300/Nexus fleet → mixed-vendor / mixed-version
    flag.
